
const size = {
  regular: 16
}

const style = {
  normal: {
    fontSize: size.regular
  }
}

export default {
  size,
  style
}
