const Colors = {
  background: '#F5FCFF',
  commonBorderColor: 'gray',
  buttonColor: 'lightblue'
};

export default Colors;