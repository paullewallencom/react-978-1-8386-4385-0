import React, { Component } from 'react';
import { AppContainer } from './Navigation/RootNavigator';

export default class App extends Component {
  render() {
    return <AppContainer />;
  }
}