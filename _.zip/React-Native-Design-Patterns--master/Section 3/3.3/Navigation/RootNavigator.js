import { StackNav } from './StackNav';
import { createAppContainer } from "react-navigation";

export const AppContainer = createAppContainer(StackNav);
