
// custom view
<View style={{ height: 50, width: 500, backgroundColor: "black" }}>
  {props.children}
</View>


// signup implementation
<CustomView>   
  <CustomText entryText={'hello world'}/>
</CustomView>   